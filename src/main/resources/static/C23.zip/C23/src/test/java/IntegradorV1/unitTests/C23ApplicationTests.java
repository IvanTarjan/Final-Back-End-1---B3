package IntegradorV1.unitTests;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
